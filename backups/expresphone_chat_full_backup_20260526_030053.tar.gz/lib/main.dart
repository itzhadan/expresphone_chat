import 'dart:async';
import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';

const String api = "https://arnonidan.pythonanywhere.com";
const String appPin = "6044";

void playIncomingAlert() {
  SystemSound.play(SystemSoundType.alert);
  HapticFeedback.heavyImpact();
}

class AfricaCountryPosition {
  const AfricaCountryPosition(
    this.code,
    this.name,
    this.x,
    this.y, {
    double? labelX,
    double? labelY,
  }) : labelX = labelX ?? x,
       labelY = labelY ?? y;

  final String code;
  final String name;
  final double x;
  final double y;
  final double labelX;
  final double labelY;
}

const List<AfricaCountryPosition> africaCountryPositions = [
  AfricaCountryPosition(
    "morocco",
    "Morocco",
    0.26,
    0.10,
    labelX: 0.21,
    labelY: 0.04,
  ),
  AfricaCountryPosition(
    "senegal",
    "Senegal",
    0.16,
    0.39,
    labelX: 0.05,
    labelY: 0.34,
  ),
  AfricaCountryPosition(
    "gambia",
    "Gambia",
    0.14,
    0.41,
    labelX: 0.03,
    labelY: 0.43,
  ),
  AfricaCountryPosition(
    "guinea_bissau",
    "Guinea-Bissau",
    0.15,
    0.45,
    labelX: 0.03,
    labelY: 0.51,
  ),
  AfricaCountryPosition(
    "guinea",
    "Guinea",
    0.20,
    0.46,
    labelX: 0.16,
    labelY: 0.56,
  ),
  AfricaCountryPosition(
    "sierra_leone",
    "Sierra Leone",
    0.20,
    0.51,
    labelX: 0.07,
    labelY: 0.61,
  ),
  AfricaCountryPosition(
    "liberia",
    "Liberia",
    0.24,
    0.55,
    labelX: 0.18,
    labelY: 0.67,
  ),
  AfricaCountryPosition(
    "ivory_coast",
    "Ivory Coast",
    0.31,
    0.54,
    labelX: 0.30,
    labelY: 0.64,
  ),
  AfricaCountryPosition(
    "ghana",
    "Ghana",
    0.38,
    0.54,
    labelX: 0.31,
    labelY: 0.43,
  ),
  AfricaCountryPosition("togo", "Togo", 0.42, 0.54, labelX: 0.43, labelY: 0.43),
  AfricaCountryPosition(
    "benin",
    "Benin",
    0.45,
    0.53,
    labelX: 0.49,
    labelY: 0.47,
  ),
  AfricaCountryPosition(
    "nigeria",
    "Nigeria",
    0.50,
    0.52,
    labelX: 0.48,
    labelY: 0.37,
  ),
  AfricaCountryPosition(
    "cameroon",
    "Cameroon",
    0.56,
    0.58,
    labelX: 0.60,
    labelY: 0.50,
  ),
  AfricaCountryPosition(
    "central_african_republic",
    "Central African Republic",
    0.64,
    0.55,
    labelX: 0.66,
    labelY: 0.42,
  ),
  AfricaCountryPosition(
    "south_sudan",
    "South Sudan",
    0.75,
    0.52,
    labelX: 0.78,
    labelY: 0.43,
  ),
  AfricaCountryPosition(
    "dr_congo",
    "DR Congo",
    0.64,
    0.70,
    labelX: 0.55,
    labelY: 0.74,
  ),
  AfricaCountryPosition(
    "uganda",
    "Uganda",
    0.78,
    0.62,
    labelX: 0.72,
    labelY: 0.57,
  ),
  AfricaCountryPosition(
    "kenya",
    "Kenya",
    0.85,
    0.64,
    labelX: 0.87,
    labelY: 0.56,
  ),
  AfricaCountryPosition(
    "rwanda",
    "Rwanda",
    0.75,
    0.68,
    labelX: 0.67,
    labelY: 0.66,
  ),
  AfricaCountryPosition(
    "burundi",
    "Burundi",
    0.76,
    0.71,
    labelX: 0.84,
    labelY: 0.70,
  ),
  AfricaCountryPosition(
    "tanzania",
    "Tanzania",
    0.81,
    0.74,
    labelX: 0.86,
    labelY: 0.78,
  ),
  AfricaCountryPosition(
    "zambia",
    "Zambia",
    0.70,
    0.82,
    labelX: 0.61,
    labelY: 0.84,
  ),
  AfricaCountryPosition(
    "malawi",
    "Malawi",
    0.78,
    0.82,
    labelX: 0.84,
    labelY: 0.86,
  ),
  AfricaCountryPosition(
    "mozambique",
    "Mozambique",
    0.83,
    0.86,
    labelX: 0.86,
    labelY: 0.91,
  ),
  AfricaCountryPosition(
    "zimbabwe",
    "Zimbabwe",
    0.74,
    0.88,
    labelX: 0.70,
    labelY: 0.94,
  ),
  AfricaCountryPosition(
    "namibia",
    "Namibia",
    0.57,
    0.91,
    labelX: 0.47,
    labelY: 0.91,
  ),
  AfricaCountryPosition(
    "south_africa",
    "South Africa",
    0.68,
    0.97,
    labelX: 0.62,
    labelY: 0.88,
  ),
  AfricaCountryPosition(
    "lesotho",
    "Lesotho",
    0.72,
    0.98,
    labelX: 0.78,
    labelY: 0.95,
  ),
  AfricaCountryPosition(
    "mauritius",
    "Mauritius",
    0.99,
    0.92,
    labelX: 0.88,
    labelY: 0.98,
  ),
  AfricaCountryPosition(
    "sao_tome",
    "Sao Tome",
    0.47,
    0.64,
    labelX: 0.39,
    labelY: 0.70,
  ),
];

void main() {
  runApp(const ExpresphoneApp());
}

class ExpresphoneApp extends StatelessWidget {
  const ExpresphoneApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Expresphone WhatsApp Dashboard",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        colorSchemeSeed: Colors.green,
        scaffoldBackgroundColor: const Color(0xff04162b),
      ),
      home: const PinPage(),
    );
  }
}

class PinPage extends StatefulWidget {
  const PinPage({super.key});

  @override
  State<PinPage> createState() => _PinPageState();
}

class _PinPageState extends State<PinPage> {
  final pin = TextEditingController();
  String error = "";
  List countries = [];
  bool loadingCountries = true;
  String selectedCountry = "all";
  Timer? refreshTimer;

  @override
  void initState() {
    super.initState();
    loadCountries();
    refreshTimer = Timer.periodic(
      const Duration(seconds: 10),
      (_) => loadCountries(silent: true),
    );
  }

  void enter() {
    if (pin.text.trim() == appPin) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => DashboardPage(initialCountry: selectedCountry),
        ),
      );
    } else {
      setState(() => error = "קוד שגוי. נסה שוב.");
      SystemSound.play(SystemSoundType.alert);
    }
  }

  Future<void> loadCountries({bool silent = false}) async {
    if (!silent) {
      loadingCountries = true;
      if (mounted) setState(() {});
    }

    try {
      final r = await http.get(Uri.parse("$api/api/countries"));
      final data = jsonDecode(r.body);
      countries = data is List ? data : [];
    } catch (_) {
      countries = [];
    }

    loadingCountries = false;
    if (mounted) setState(() {});
  }

  void selectCountry(String code) {
    setState(() => selectedCountry = code);
    showSnack("נבחרה מדינה: ${countryTitle(code)}. הכנס PIN כדי להמשיך.");
  }

  void showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Map<String, dynamic> get countryByCode {
    return {
      for (final item in countries)
        if (item is Map && item["code"] != null) "${item["code"]}": item,
    };
  }

  String countryTitle(String code) {
    if (code == "all") return "כל המדינות";
    final data = countryByCode[code];
    return "${data?["name"] ?? africaCountryPositions.firstWhere((x) => x.code == code).name}";
  }

  @override
  void dispose() {
    refreshTimer?.cancel();
    pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mapPanel = _AfricaMapPanel(
      countries: countryByCode,
      selectedCountry: selectedCountry,
      loading: loadingCountries,
      onSelectCountry: selectCountry,
    );

    return Scaffold(
      backgroundColor: const Color(0xff021225),
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(-0.24, -0.26),
            radius: 1.25,
            colors: [Color(0xff0b315f), Color(0xff031b36), Color(0xff010b18)],
            stops: [0.0, 0.48, 1.0],
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Container(
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                gradient: const RadialGradient(
                  center: Alignment(-0.22, -0.12),
                  radius: 1.08,
                  colors: [
                    Color(0xff0a2d56),
                    Color(0xff031b35),
                    Color(0xff010915),
                  ],
                  stops: [0.0, 0.58, 1.0],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: const Color(0xff6aa9ff).withValues(alpha: 0.26),
                ),
                boxShadow: const [
                  BoxShadow(color: Color(0x99000718), blurRadius: 28),
                ],
              ),
              child: Column(
                children: [
                  _Header(pin: pin, error: error, onLogin: enter),
                  Expanded(child: mapPanel),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.pin,
    required this.error,
    required this.onLogin,
  });

  final TextEditingController pin;
  final String error;
  final VoidCallback onLogin;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final title = const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "yvohana",
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                letterSpacing: 0,
              ),
            ),
          ],
        );
        final pinBox = SizedBox(
          width: constraints.maxWidth < 420 ? 70 : 94,
          height: 30,
          child: TextField(
            controller: pin,
            obscureText: true,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900),
            decoration: InputDecoration(
              hintText: "PIN",
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(vertical: 5),
              filled: true,
              fillColor: const Color(0xff06213f),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Colors.white.withValues(alpha: 0.70),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide(
                  color: Colors.white.withValues(alpha: 0.70),
                ),
              ),
            ),
            onSubmitted: (_) => onLogin(),
          ),
        );
        final loginButton = SizedBox(
          height: 30,
          child: FilledButton(
            onPressed: onLogin,
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xff2f8cff),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 9),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: const Text(
              "כניסה",
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
            ),
          ),
        );

        final controls = Row(
          mainAxisSize: MainAxisSize.min,
          children: [pinBox, const SizedBox(width: 6), loginButton],
        );

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0x33082a50),
            border: Border(
              bottom: BorderSide(
                color: Colors.white.withValues(alpha: 0.16),
                width: 1,
              ),
            ),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(child: title),
                  const SizedBox(width: 8),
                  controls,
                ],
              ),
              if (error.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    error,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Colors.redAccent,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _AfricaMapPanel extends StatelessWidget {
  const _AfricaMapPanel({
    required this.countries,
    required this.selectedCountry,
    required this.loading,
    required this.onSelectCountry,
  });

  final Map<String, dynamic> countries;
  final String selectedCountry;
  final bool loading;
  final ValueChanged<String> onSelectCountry;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(2, 2, 2, 6),
      decoration: const BoxDecoration(color: Colors.transparent),
      child: Stack(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final mapWidth = constraints.maxWidth;
              final mapHeight = constraints.maxHeight;
              return Stack(
                clipBehavior: Clip.hardEdge,
                children: [
                  Positioned(
                    left: 0,
                    top: 0,
                    width: mapWidth,
                    height: mapHeight,
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Positioned.fill(
                          child: Image.asset(
                            "assets/africa_cutout.png",
                            fit: BoxFit.fill,
                          ),
                        ),
                        for (final country in africaCountryPositions)
                          _CountryMarker(
                            position: country,
                            data: countries[country.code],
                            selected: selectedCountry == country.code,
                            mapWidth: mapWidth,
                            mapHeight: mapHeight,
                            onTap: () => onSelectCountry(country.code),
                          ),
                      ],
                    ),
                  ),
                ],
              );
            },
          ),
          if (loading)
            const Positioned(
              left: 10,
              top: 10,
              child: Text(
                "טוען מדינות...",
                style: TextStyle(fontSize: 14, color: Colors.white70),
              ),
            ),
        ],
      ),
    );
  }
}

class _CountryMarker extends StatelessWidget {
  const _CountryMarker({
    required this.position,
    required this.data,
    required this.selected,
    required this.mapWidth,
    required this.mapHeight,
    required this.onTap,
  });

  final AfricaCountryPosition position;
  final dynamic data;
  final bool selected;
  final double mapWidth;
  final double mapHeight;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final unread = int.tryParse("${data?["unread"] ?? 0}") ?? 0;
    final available = _availableCountForCountry(data);
    final hasUnread = unread > 0;
    final hasAvailable = available > 0;
    final statusColor = hasUnread
        ? Colors.redAccent
        : hasAvailable
        ? Colors.greenAccent
        : Colors.blueGrey.shade200;
    final badgeText = hasUnread
        ? (unread > 99 ? "99" : "$unread")
        : (available > 99 ? "99" : "$available");
    final label = "${data?["name"] ?? position.name}";
    final flag = "${data?["flag"] ?? _flagForCountry(position.code)}";
    final point = Offset(position.x * mapWidth, position.y * mapHeight);
    final compact = mapWidth < 520;
    final tagWidth = compact ? 50.0 : 64.0;
    final tagHeight = compact ? 25.0 : 29.0;
    final tagLeft = (position.labelX * mapWidth - tagWidth / 2)
        .clamp(0.0, mapWidth > tagWidth ? mapWidth - tagWidth : 0.0)
        .toDouble();
    final tagTop = (position.labelY * mapHeight - tagHeight / 2)
        .clamp(0.0, mapHeight > tagHeight ? mapHeight - tagHeight : 0.0)
        .toDouble();
    final leaderStart = Offset(tagLeft + tagWidth / 2, tagTop + tagHeight);

    return Positioned.fill(
      child: Semantics(
        button: true,
        label:
            "$label, ${hasUnread ? "$unread הודעות שלא נקראו" : "$available זמינים"}",
        child: Stack(
          children: [
            CustomPaint(
              foregroundPainter: _CountryLeaderPainter(
                from: leaderStart,
                to: point,
                color: Colors.white,
              ),
              size: Size(mapWidth, mapHeight),
            ),
            Positioned(
              left: point.dx - 6,
              top: point.dy - 6,
              child: GestureDetector(
                onTap: onTap,
                child: _GlowDot(color: statusColor),
              ),
            ),
            Positioned(
              left: tagLeft,
              top: tagTop,
              child: Tooltip(
                message: label,
                child: InkWell(
                  onTap: onTap,
                  borderRadius: BorderRadius.circular(18),
                  child: _CountryTag(
                    color: Colors.white,
                    badgeColor: statusColor,
                    badgeText: badgeText,
                    flag: flag,
                    selected: selected,
                    compact: compact,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

int _availableCountForCountry(dynamic data) {
  if (data is! Map) return 0;
  const keys = [
    "available",
    "available_count",
    "online",
    "online_count",
    "active",
    "active_count",
  ];
  for (final key in keys) {
    final value = data[key];
    final parsed = int.tryParse("$value");
    if (parsed != null && parsed > 0) return parsed;
    if (value == true) return 1;
  }
  return data["token"] == true ? 1 : 0;
}

class _CountryLeaderPainter extends CustomPainter {
  const _CountryLeaderPainter({
    required this.from,
    required this.to,
    required this.color,
  });

  final Offset from;
  final Offset to;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final halo = Paint()
      ..color = Colors.white.withValues(alpha: 0.10)
      ..strokeWidth = 5.0
      ..strokeCap = StrokeCap.round;
    final glow = Paint()
      ..color = Colors.white.withValues(alpha: 0.28)
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round;
    final line = Paint()
      ..color = Colors.white.withValues(alpha: 0.88)
      ..strokeWidth = 1.0
      ..strokeCap = StrokeCap.round;
    final highlight = Paint()
      ..color = Colors.white.withValues(alpha: 0.90)
      ..strokeWidth = 0.6
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(from, to, halo);
    canvas.drawLine(from, to, glow);
    canvas.drawLine(from, to, line);
    canvas.drawLine(from, to, highlight);
  }

  @override
  bool shouldRepaint(covariant _CountryLeaderPainter oldDelegate) {
    return from != oldDelegate.from ||
        to != oldDelegate.to ||
        color != oldDelegate.color;
  }
}

class _GlowDot extends StatelessWidget {
  const _GlowDot({required this.color});

  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 12,
      height: 12,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.88),
        shape: BoxShape.circle,
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.72),
          width: 1.1,
        ),
        boxShadow: [
          BoxShadow(color: color.withValues(alpha: 0.60), blurRadius: 8),
          BoxShadow(color: color.withValues(alpha: 0.30), blurRadius: 16),
        ],
      ),
      child: Center(
        child: Container(
          width: 4,
          height: 4,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.white.withValues(alpha: 0.72),
                blurRadius: 5,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountryTag extends StatelessWidget {
  const _CountryTag({
    required this.color,
    required this.badgeColor,
    required this.badgeText,
    required this.flag,
    required this.selected,
    required this.compact,
  });

  final Color color;
  final Color badgeColor;
  final String badgeText;
  final String flag;
  final bool selected;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final width = compact ? 50.0 : 64.0;
    final height = compact ? 25.0 : 29.0;
    final flagSize = compact ? 13.0 : 15.0;
    final badgeHeight = compact ? 15.0 : 17.0;
    return SizedBox(
      width: width,
      height: height,
      child: Stack(
        alignment: Alignment.topCenter,
        children: [
          Positioned(
            top: height - 10,
            child: Transform.rotate(
              angle: 0.785398,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: const Color(0xee082a50),
                  border: Border(
                    right: BorderSide(
                      color: color.withValues(alpha: 0.58),
                      width: 1,
                    ),
                    bottom: BorderSide(
                      color: color.withValues(alpha: 0.58),
                      width: 1,
                    ),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withValues(alpha: 0.16),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
            ),
          ),
          Container(
            width: width,
            height: height - 6,
            padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
            decoration: BoxDecoration(
              color: const Color(0xee082a50),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                color: selected
                    ? Colors.white
                    : Colors.white.withValues(alpha: 0.72),
                width: selected ? 2.4 : 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.white.withValues(alpha: 0.14),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Row(
              children: [
                Text(flag, style: TextStyle(fontSize: flagSize)),
                const Spacer(),
                const SizedBox(width: 3),
                Container(
                  constraints: BoxConstraints(minWidth: badgeHeight),
                  height: badgeHeight,
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  decoration: BoxDecoration(
                    color: badgeColor,
                    borderRadius: BorderRadius.circular(9),
                    boxShadow: [
                      BoxShadow(
                        color: badgeColor.withValues(alpha: 0.40),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Text(
                    badgeText,
                    style: const TextStyle(
                      fontSize: 7,
                      color: Colors.black,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

String _flagForCountry(String code) {
  switch (code) {
    case "algeria":
      return "🇩🇿";
    case "angola":
      return "🇦🇴";
    case "benin":
      return "🇧🇯";
    case "botswana":
      return "🇧🇼";
    case "burkina_faso":
      return "🇧🇫";
    case "burundi":
      return "🇧🇮";
    case "cameroon":
      return "🇨🇲";
    case "cape_verde":
      return "🇨🇻";
    case "central_african_republic":
      return "🇨🇫";
    case "chad":
      return "🇹🇩";
    case "comoros":
      return "🇰🇲";
    case "congo":
      return "🇨🇬";
    case "dr_congo":
      return "🇨🇩";
    case "djibouti":
      return "🇩🇯";
    case "egypt":
      return "🇪🇬";
    case "equatorial_guinea":
      return "🇬🇶";
    case "eritrea":
      return "🇪🇷";
    case "eswatini":
      return "🇸🇿";
    case "ethiopia":
      return "🇪🇹";
    case "gabon":
      return "🇬🇦";
    case "gambia":
      return "🇬🇲";
    case "ghana":
      return "🇬🇭";
    case "guinea":
      return "🇬🇳";
    case "guinea_bissau":
      return "🇬🇼";
    case "ivory_coast":
      return "🇨🇮";
    case "kenya":
      return "🇰🇪";
    case "lesotho":
      return "🇱🇸";
    case "liberia":
      return "🇱🇷";
    case "libya":
      return "🇱🇾";
    case "madagascar":
      return "🇲🇬";
    case "malawi":
      return "🇲🇼";
    case "mali":
      return "🇲🇱";
    case "mauritania":
      return "🇲🇷";
    case "mauritius":
      return "🇲🇺";
    case "morocco":
      return "🇲🇦";
    case "mozambique":
      return "🇲🇿";
    case "namibia":
      return "🇳🇦";
    case "niger":
      return "🇳🇪";
    case "nigeria":
      return "🇳🇬";
    case "rwanda":
      return "🇷🇼";
    case "sao_tome":
      return "🇸🇹";
    case "senegal":
      return "🇸🇳";
    case "seychelles":
      return "🇸🇨";
    case "sierra_leone":
      return "🇸🇱";
    case "somalia":
      return "🇸🇴";
    case "south_africa":
      return "🇿🇦";
    case "south_sudan":
      return "🇸🇸";
    case "sudan":
      return "🇸🇩";
    case "tanzania":
      return "🇹🇿";
    case "togo":
      return "🇹🇬";
    case "tunisia":
      return "🇹🇳";
    case "uganda":
      return "🇺🇬";
    case "western_sahara":
      return "🇪🇭";
    case "zambia":
      return "🇿🇲";
    case "zimbabwe":
      return "🇿🇼";
    default:
      return "🏳️";
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key, this.initialCountry = "all"});

  final String initialCountry;

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List countries = [];
  List chats = [];
  String selectedCountry = "all";
  String search = "";
  bool loadingCountries = true;
  bool loadingChats = true;
  String chatsError = "";
  String countriesError = "";
  int lastTotalUnread = 0;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    selectedCountry = widget.initialCountry;
    loadAll();
    timer = Timer.periodic(
      const Duration(seconds: 6),
      (_) => loadAll(silent: true),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> loadAll({bool silent = false}) async {
    await loadCountries(silent: silent);
    await loadChats(selectedCountry, silent: silent);
  }

  Future<void> loadCountries({bool silent = false}) async {
    if (!silent) {
      loadingCountries = true;
      countriesError = "";
      if (mounted) setState(() {});
    }

    try {
      final r = await http
          .get(Uri.parse("$api/api/countries"))
          .timeout(const Duration(seconds: 8));
      if (r.statusCode < 200 || r.statusCode >= 300) {
        throw Exception("countries ${r.statusCode}");
      }
      final data = jsonDecode(r.body);
      countries = data is List ? data : [];
      final newUnread = countries.fold<int>(
        0,
        (sum, item) => sum + (int.tryParse("${item["unread"] ?? 0}") ?? 0),
      );

      if (lastTotalUnread > 0 && newUnread > lastTotalUnread && mounted) {
        playIncomingAlert();
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("🔔 הודעה חדשה נכנסה")));
      }
      lastTotalUnread = newUnread;
    } catch (_) {
      if (!silent) countriesError = "לא הצלחתי לטעון מדינות. נסה שוב.";
    } finally {
      loadingCountries = false;
      if (mounted) setState(() {});
    }
  }

  Future<void> loadChats(String country, {bool silent = false}) async {
    selectedCountry = country;

    if (!silent) {
      loadingChats = true;
      chatsError = "";
      if (mounted) setState(() {});
    }

    try {
      final uri = Uri.parse(
        "$api/api/chats",
      ).replace(queryParameters: {"country": country});
      final r = await http.get(uri).timeout(const Duration(seconds: 8));
      if (r.statusCode < 200 || r.statusCode >= 300) {
        throw Exception("chats ${r.statusCode}");
      }
      final data = jsonDecode(r.body);
      chats = data is List ? data : [];
    } catch (_) {
      if (!silent) chatsError = "השרת לא החזיר שיחות. בדוק אינטרנט ונסה שוב.";
    } finally {
      loadingChats = false;
      if (mounted) setState(() {});
    }
  }

  List get filteredChats {
    final q = search.trim().toLowerCase();
    if (q.isEmpty) return chats;
    return chats.where((x) {
      final name = "${x["name"] ?? ""}".toLowerCase();
      final phone = "${x["wa_id"] ?? ""}".toLowerCase();
      return name.contains(q) || phone.contains(q);
    }).toList();
  }

  int countryUnread(dynamic x) => int.tryParse("${x["unread"] ?? 0}") ?? 0;

  @override
  Widget build(BuildContext context) {
    final list = filteredChats;

    return Scaffold(
      backgroundColor: const Color(0xff021225),
      appBar: AppBar(
        backgroundColor: const Color(0xff06213f),
        title: const Text(
          "yvohana chat",
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        actions: [
          IconButton(
            onPressed: () => loadAll(),
            icon: const Icon(Icons.refresh),
          ),
          IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (_) => const PinPage()),
              );
            },
            icon: const Icon(Icons.lock),
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            height: 126,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xff082a50), Color(0xff031b35)],
              ),
            ),
            child: loadingCountries
                ? const Center(child: CircularProgressIndicator())
                : countriesError.isNotEmpty
                ? _LoadError(message: countriesError, onRetry: loadAll)
                : ListView(
                    scrollDirection: Axis.horizontal,
                    children: [
                      countryCircle("🌍", "ALL", "all", 0, true),
                      ...countries.map(
                        (x) => countryCircle(
                          "${x["flag"] ?? "🌍"}",
                          "${x["name"] ?? ""}",
                          "${x["code"] ?? ""}",
                          countryUnread(x),
                          x["token"] == true,
                        ),
                      ),
                    ],
                  ),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              onChanged: (v) => setState(() => search = v),
              decoration: InputDecoration(
                hintText: "🔍 חיפוש לקוח / מספר",
                filled: true,
                fillColor: const Color(0xff202c33),
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
            ),
          ),
          Expanded(
            child: loadingChats
                ? const Center(child: CircularProgressIndicator())
                : chatsError.isNotEmpty
                ? _LoadError(
                    message: chatsError,
                    onRetry: () => loadChats(selectedCountry),
                  )
                : list.isEmpty
                ? const Center(
                    child: Text(
                      "אין שיחות להצגה",
                      style: TextStyle(fontSize: 22),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 12),
                    itemCount: list.length,
                    itemBuilder: (context, i) => chatCard(list[i]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget countryCircle(
    String flag,
    String name,
    String code,
    int unread,
    bool hasToken,
  ) {
    final active = selectedCountry == code;

    return GestureDetector(
      onTap: () => loadChats(code),
      child: Container(
        width: 92,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        decoration: BoxDecoration(
          color: active ? const Color(0xff123f32) : const Color(0xee082a50),
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: active
                ? Colors.greenAccent
                : Colors.white.withValues(alpha: 0.18),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: (hasToken ? Colors.greenAccent : Colors.blueAccent)
                  .withValues(alpha: 0.12),
              blurRadius: 12,
            ),
          ],
        ),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(flag, style: const TextStyle(fontSize: 30)),
                  const SizedBox(height: 4),
                  Icon(
                    Icons.circle,
                    size: 10,
                    color: hasToken ? Colors.greenAccent : Colors.grey,
                  ),
                  const SizedBox(height: 4),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5),
                    child: Text(
                      name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (unread > 0)
              Positioned(
                top: 7,
                right: 8,
                child: CircleAvatar(
                  radius: 15,
                  backgroundColor: Colors.red,
                  child: Text(
                    "$unread",
                    style: const TextStyle(fontSize: 11, color: Colors.white),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget chatCard(dynamic x) {
    final name = "${x["name"] ?? ""}".trim();
    final waId = "${x["wa_id"] ?? ""}";
    final unread = int.tryParse("${x["unread"] ?? 0}") ?? 0;
    final lastSeen = "${x["last_seen"] ?? ""}";
    final online = x["online"] == true;

    return Card(
      color: const Color(0xee082a50),
      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
        side: BorderSide(color: Colors.white.withValues(alpha: 0.14)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(12),
        leading: CircleAvatar(
          radius: 28,
          backgroundColor: Colors.green,
          child: Text(
            name.isNotEmpty ? name[0].toUpperCase() : "👤",
            style: const TextStyle(
              color: Colors.white,
              fontSize: 22,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        title: Text(
          name.isEmpty ? "ללא שם" : name,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("📞 $waId"),
            const SizedBox(height: 4),
            Text(
              online
                  ? "🟢 זמין"
                  : (lastSeen.isEmpty
                        ? "⚫ לא מחובר"
                        : "נראה לאחרונה $lastSeen"),
              style: TextStyle(color: online ? Colors.green : Colors.grey),
            ),
          ],
        ),
        trailing: unread > 0
            ? CircleAvatar(
                backgroundColor: Colors.red,
                child: Text(
                  "$unread",
                  style: const TextStyle(color: Colors.white),
                ),
              )
            : const Icon(Icons.chevron_left),
        onTap: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  ChatPage(waId: waId, name: name.isEmpty ? waId : name),
            ),
          );
          loadAll(silent: true);
        },
      ),
    );
  }
}

class _LoadError extends StatelessWidget {
  const _LoadError({required this.message, required this.onRetry});

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off, size: 42, color: Colors.orangeAccent),
            const SizedBox(height: 10),
            Text(
              message,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text("נסה שוב"),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  final String waId;
  final String name;

  const ChatPage({super.key, required this.waId, required this.name});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ScrollController scrollController = ScrollController();
  List msgs = [];
  bool loading = true;
  bool sending = false;
  Timer? timer;
  int lastCount = 0;
  final txt = TextEditingController();

  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (mounted) {
        load(silent: true);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    scrollController.dispose();
    txt.dispose();
    super.dispose();
  }

  Future<void> load({bool silent = false}) async {
    if (!silent) {
      loading = true;
      if (mounted) setState(() {});
    }

    try {
      final r = await http.get(
        Uri.parse("$api/api/messages?wa_id=${widget.waId}"),
      );
      final data = jsonDecode(r.body);
      msgs = data is List ? data : [];

      if (lastCount > 0 && msgs.length > lastCount && mounted) {
        playIncomingAlert();
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text("🔔 הודעה חדשה בשיחה")));
      }
      lastCount = msgs.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && scrollController.hasClients) {
          scrollController.jumpTo(scrollController.position.maxScrollExtent);
        }
      });
    } catch (_) {
      msgs = [];
    }

    loading = false;
    if (mounted) setState(() {});
  }

  Future<void> sendText({bool translateFirst = false}) async {
    String text = txt.text.trim();
    if (text.isEmpty || sending) return;

    setState(() => sending = true);

    if (translateFirst) {
      final translated = await translateOnly(text, target: "en");
      if (!isUsableEnglishTranslation(original: text, translated: translated)) {
        showSnack("התרגום לאנגלית נכשל. ההודעה לא נשלחה.");
        if (mounted) setState(() => sending = false);
        return;
      }
      text = translated;
    }

    try {
      final r = await http
          .post(
            Uri.parse("$api/api/send"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"wa_id": widget.waId, "msg": text}),
          )
          .timeout(const Duration(seconds: 15));
      if (r.statusCode < 200 || r.statusCode >= 300) {
        showSnack("שגיאה בשליחה: ${r.statusCode}");
        return;
      }
      txt.clear();
      await load();
      if (translateFirst) showSnack("נשלח באנגלית");
    } catch (e) {
      showSnack("לא הצלחתי לשלוח. בדוק אינטרנט ונסה שוב.");
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  Future<String> translateOnly(String text, {String target = "he"}) async {
    final original = text.trim();
    try {
      final r = await http
          .post(
            Uri.parse("$api/api/translate"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({
              "text": text,
              "target": target,
              "target_lang": target,
              "to": target,
            }),
          )
          .timeout(const Duration(seconds: 12));
      final data = jsonDecode(r.body);
      final translated = "${data["translated"] ?? text}".trim();
      if (isUsefulTranslation(
        original: original,
        translated: translated,
        target: target,
      )) {
        return translated;
      }
    } catch (_) {
      // Fall through to the public fallback below.
    }

    return translateWithGoogleFallback(original, target: target);
  }

  Future<String> translateWithGoogleFallback(
    String text, {
    required String target,
  }) async {
    try {
      final uri = Uri.https("translate.googleapis.com", "/translate_a/single", {
        "client": "gtx",
        "sl": "auto",
        "tl": target,
        "dt": "t",
        "q": text,
      });
      final r = await http.get(uri).timeout(const Duration(seconds: 12));
      if (r.statusCode < 200 || r.statusCode >= 300) return text;
      final data = jsonDecode(r.body);
      final pieces = data is List && data.isNotEmpty ? data[0] : null;
      if (pieces is! List) return text;
      final translated = pieces
          .whereType<List>()
          .map((part) => part.isNotEmpty ? "${part.first}" : "")
          .join()
          .trim();
      if (isUsefulTranslation(
        original: text,
        translated: translated,
        target: target,
      )) {
        return translated;
      }
    } catch (_) {
      // Keep the original text when every translation path fails.
    }
    return text;
  }

  bool isUsableEnglishTranslation({
    required String original,
    required String translated,
  }) {
    return isUsefulTranslation(
      original: original,
      translated: translated,
      target: "en",
    );
  }

  bool isUsefulTranslation({
    required String original,
    required String translated,
    required String target,
  }) {
    final cleanOriginal = original.trim();
    final cleanTranslated = translated.trim();
    if (cleanTranslated.isEmpty) return false;
    if (cleanTranslated == cleanOriginal) return false;
    final hasHebrew = RegExp(r"[\u0590-\u05ff]").hasMatch(cleanTranslated);
    if (target == "en") return !hasHebrew;
    if (target == "he") return hasHebrew;
    return true;
  }

  Future<void> showTranslation(String text) async {
    final translated = await translateOnly(text, target: "he");
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("🌍 תרגום"),
        content: SelectableText(translated),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("סגור"),
          ),
        ],
      ),
    );
  }

  Future<void> chooseAndSendFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        withData: true,
        allowMultiple: false,
        type: FileType.any,
      );
      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      final extension = fileExtension(file.name, file.extension);
      final contentType = mediaTypeForExtension(extension);
      final bytes = file.bytes;
      if (bytes == null) {
        showSnack("לא הצלחתי לקרוא את הקובץ");
        return;
      }
      if (bytes.length > 15 * 1024 * 1024) {
        showSnack("הקובץ גדול מדי. עד 15MB");
        return;
      }

      setState(() => sending = true);

      final req = http.MultipartRequest("POST", Uri.parse("$api/api/upload"));
      req.fields["wa_id"] = widget.waId;
      req.fields["filename"] = file.name;
      req.fields["mime_type"] = contentType.toString();
      req.files.add(
        http.MultipartFile.fromBytes(
          "file",
          bytes,
          filename: file.name,
          contentType: contentType,
        ),
      );

      final res = await req.send().timeout(const Duration(seconds: 30));
      if (res.statusCode >= 200 && res.statusCode < 300) {
        showSnack("📎 הקובץ נשלח");
        await load();
      } else {
        final body = await res.stream.bytesToString();
        showSnack(uploadErrorMessage(res.statusCode, body));
      }
    } on PlatformException catch (e) {
      showSnack("בחירת קובץ נכשלה: ${e.message ?? e.code}");
    } on TimeoutException {
      showSnack("העלאת הקובץ לקחה יותר מדי זמן. נסה שוב.");
    } catch (e) {
      showSnack("שגיאה: $e");
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  String uploadErrorMessage(int statusCode, String body) {
    if (statusCode >= 500 && body.contains("whatsapp upload failed")) {
      return "הקובץ נבחר, אבל WhatsApp לא קיבל אותו. אם זה HEIC/קובץ נדיר, נסה לשמור כ-JPG/PDF.";
    }
    if (statusCode == 413) return "הקובץ גדול מדי לשליחה.";
    if (statusCode == 415) return "סוג הקובץ לא נתמך לשליחה.";
    return "שגיאה בשליחת קובץ: $statusCode";
  }

  String fileExtension(String name, String? pickerExtension) {
    final fromPicker = (pickerExtension ?? "").toLowerCase().trim();
    if (fromPicker.isNotEmpty) return fromPicker;
    final index = name.lastIndexOf(".");
    if (index == -1 || index == name.length - 1) return "";
    return name.substring(index + 1).toLowerCase();
  }

  MediaType mediaTypeForExtension(String extension) {
    switch (extension) {
      case "jpg":
      case "jpeg":
        return MediaType("image", "jpeg");
      case "png":
        return MediaType("image", "png");
      case "gif":
        return MediaType("image", "gif");
      case "webp":
        return MediaType("image", "webp");
      case "heic":
        return MediaType("image", "heic");
      case "heif":
        return MediaType("image", "heif");
      case "pdf":
        return MediaType("application", "pdf");
      case "txt":
        return MediaType("text", "plain");
      case "csv":
        return MediaType("text", "csv");
      case "doc":
        return MediaType("application", "msword");
      case "docx":
        return MediaType(
          "application",
          "vnd.openxmlformats-officedocument.wordprocessingml.document",
        );
      case "xls":
        return MediaType("application", "vnd.ms-excel");
      case "xlsx":
        return MediaType(
          "application",
          "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        );
      case "ppt":
        return MediaType("application", "vnd.ms-powerpoint");
      case "pptx":
        return MediaType(
          "application",
          "vnd.openxmlformats-officedocument.presentationml.presentation",
        );
      case "mp3":
        return MediaType("audio", "mpeg");
      case "ogg":
        return MediaType("audio", "ogg");
      case "opus":
        return MediaType("audio", "opus");
      case "m4a":
        return MediaType("audio", "mp4");
      case "wav":
        return MediaType("audio", "wav");
      case "mp4":
        return MediaType("video", "mp4");
      case "mov":
        return MediaType("video", "quicktime");
      case "zip":
        return MediaType("application", "zip");
      case "json":
        return MediaType("application", "json");
      default:
        return MediaType("application", "octet-stream");
    }
  }

  Future<void> forwardMessage(dynamic m) async {
    final controller = TextEditingController();
    final forwardTo = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("↪️ העברת הודעה"),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.phone,
          decoration: const InputDecoration(hintText: "9725XXXXXXXX"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("ביטול"),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text("שלח"),
          ),
        ],
      ),
    );
    // controller dispose removed to avoid dialog crash

    if (forwardTo == null || forwardTo.isEmpty) return;

    try {
      final r = await http.post(
        Uri.parse("$api/api/forward"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "from_wa_id": widget.waId,
          "forward_to": forwardTo,
          "text": "${m["text"] ?? ""}",
          "media": "${m["media"] ?? ""}",
        }),
      );

      if (r.statusCode >= 200 && r.statusCode < 300) {
        showSnack("↪️ ההודעה הועברה");
      } else {
        showSnack("שגיאה בהעברה: ${r.statusCode}");
      }
    } catch (e) {
      showSnack("שגיאה: $e");
    }
  }

  void showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  String fileUrl(String? file) {
    if (file == null || file.isEmpty) return "";
    return "$api/file/$file";
  }

  String flagFor(String country) {
    switch (country.toLowerCase()) {
      case "israel":
        return "🇮🇱";
      case "ghana":
        return "🇬🇭";
      case "nigeria":
        return "🇳🇬";
      case "kenya":
        return "🇰🇪";
      default:
        return "🌍";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xff0b141a),
      appBar: AppBar(
        backgroundColor: const Color(0xff202c33),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.name),
            Text("📞 ${widget.waId}", style: const TextStyle(fontSize: 12)),
          ],
        ),
        actions: [
          IconButton(onPressed: () => load(), icon: const Icon(Icons.refresh)),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator())
                : msgs.isEmpty
                ? const Center(
                    child: Text(
                      "אין הודעות עדיין",
                      style: TextStyle(fontSize: 20),
                    ),
                  )
                : ListView.builder(
                    controller: scrollController,
                    padding: const EdgeInsets.all(10),
                    itemCount: msgs.length,
                    itemBuilder: (context, i) => bubble(msgs[i]),
                  ),
          ),
          inputBar(),
        ],
      ),
    );
  }

  Widget bubble(dynamic m) {
    final sender = "${m["sender"] ?? ""}";
    final mine = sender == "out";
    final type = "${m["type"] ?? "text"}";
    final text = "${m["text"] ?? ""}";
    final media = "${m["media"] ?? ""}";
    final time = "${m["time"] ?? ""}";
    final country = "${m["country"] ?? ""}";
    final parts = text.split("|||");

    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 340),
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: mine ? const Color(0xff005c4b) : const Color(0xff202c33),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(flagFor(country), style: const TextStyle(fontSize: 18)),
            const SizedBox(height: 4),
            mediaWidget(type, media, text),
            if (type == "text" || media.isEmpty)
              Text(parts.first, style: const TextStyle(fontSize: 17)),
            if (parts.length > 1)
              Padding(
                padding: const EdgeInsets.only(top: 7),
                child: Text(
                  "🌍 ${parts[1]}",
                  style: const TextStyle(color: Colors.lightBlueAccent),
                ),
              ),
            const SizedBox(height: 8),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    time,
                    style: const TextStyle(fontSize: 10, color: Colors.white60),
                  ),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => showTranslation(parts.first),
                  child: const Text(
                    "🌍 תרגם",
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.lightBlueAccent,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => forwardMessage(m),
                  child: const Text(
                    "↪️ העבר",
                    style: TextStyle(fontSize: 12, color: Colors.greenAccent),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget mediaWidget(String type, String media, String text) {
    if (media.isEmpty) return const SizedBox.shrink();
    final url = fileUrl(media);

    if (type == "image") {
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.network(
            url,
            width: 310,
            height: 230,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) =>
                SelectableText("📷 תמונה\n$url"),
          ),
        ),
      );
    }

    if (type == "audio") return mediaBox("🎤 הודעה קולית", url);
    if (type == "video") return mediaBox("🎥 וידאו", url);
    if (type == "document") return mediaBox("📄 קובץ", url);
    return mediaBox("📎 מדיה", url);
  }

  Widget mediaBox(String title, String url) {
    return Container(
      width: 310,
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black26,
        borderRadius: BorderRadius.circular(12),
      ),
      child: SelectableText("$title\n$url"),
    );
  }

  Widget inputBar() {
    return SafeArea(
      child: Container(
        padding: const EdgeInsets.all(8),
        color: const Color(0xff202c33),
        child: Row(
          children: [
            IconButton(
              onPressed: sending ? null : chooseAndSendFile,
              icon: const Icon(Icons.attach_file, color: Colors.orangeAccent),
            ),
            Expanded(
              child: TextField(
                controller: txt,
                minLines: 1,
                maxLines: 4,
                decoration: InputDecoration(
                  hintText: "כתוב הודעה...",
                  filled: true,
                  fillColor: const Color(0xff111b21),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                ),
              ),
            ),
            IconButton(
              onPressed: sending ? null : () => sendText(translateFirst: true),
              tooltip: "שלח באנגלית",
              icon: const Icon(Icons.translate, color: Colors.lightBlueAccent),
            ),
            IconButton(
              onPressed: sending ? null : () => sendText(),
              icon: sending
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.send, color: Colors.greenAccent),
            ),
          ],
        ),
      ),
    );
  }
}
